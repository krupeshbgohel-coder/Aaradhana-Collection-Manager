# Aaradhana Collection Manager — Android APK Project

Native Android WebView wrapper around the offline collection manager HTML app.

## Build
Open this folder in Android Studio and build `app` → `assembleDebug`.

Package: `com.aaradhana.collectionmanager`
Min Android: 7.0 (API 24)
Target: Android 15 (API 35)

The project includes the custom app icon and splash screen.
