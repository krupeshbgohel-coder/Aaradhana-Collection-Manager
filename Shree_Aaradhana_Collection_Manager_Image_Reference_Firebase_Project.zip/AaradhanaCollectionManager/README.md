# Shree Aaradhana Collection Manager — Image Reference Project

This Android Studio source project is based on the supplied 20-screen UI reference. It retains the existing mobile-first Blue & White app UI, Gujarati/Hindi/English selector, local-storage workflows, app icon and splash screen from the provided source ZIP. Firebase Android dependencies and a native Firebase Auth/Firestore bridge have been added.

## Project details
- Android package: `com.aaradhana.collectionmanager`
- Firebase project expected by the included `app/google-services.json`: `shree-aaradhana-manager`
- Firebase Auth: Anonymous sign-in (suitable only as a temporary single-device bootstrap)
- Firestore path: `users/{uid}/appData/snapshot`
- Cloud action: use **Sync to Cloud** in the app; the app does not automatically overwrite local data with cloud data. Existing local records are preserved when a cloud snapshot is found.
- Existing modules include dashboard, members, savings collection/history, gift slab/eligibility/issue history, loan eligibility/application/approval/repayment, reports, settings and commission tracking. Exact business rules should be verified before real financial use.

## Firebase Console setup
1. Open project `shree-aaradhana-manager`.
2. Authentication → Sign-in method → enable **Anonymous**.
3. Cloud Firestore → Rules → publish the supplied `firestore.rules` (or the same owner-scoped rules you already published).
4. Confirm the Android app package is exactly `com.aaradhana.collectionmanager`.
5. Keep the included `app/google-services.json` for that same Firebase project.

## Build APK
1. Download/extract this ZIP on a computer.
2. Open the `AaradhanaCollectionManager` folder in Android Studio.
3. Allow Gradle sync to finish.
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Install `app/build/outputs/apk/debug/app-debug.apk` on your Android phone.
6. Open the app, wait for cloud status, and tap **Sync to Cloud**. Check Firestore → Data for `users/{uid}/appData/snapshot`.

## Important status and limitations
- This is a source-project ZIP, not an APK. It has not been built or device-tested in this environment; Gradle build success and real-device Firebase connection are not yet verified.
- Cloud sync currently saves the app database as one JSON snapshot. It is not multi-user/branch-safe synchronization, does not merge simultaneous edits, and does not provide per-staff permissions. Do not enter sensitive/production customer data until testing and role-based access are implemented.
- Anonymous users may lose access to their cloud path if app data is cleared/reinstalled and a new UID is created. For multi-device use, implement named owner/staff accounts and organization/role-based Firestore rules first.
- If Gradle sync fails, check internet access, Android Studio/Gradle compatibility and that `google-services.json` matches the application ID.
