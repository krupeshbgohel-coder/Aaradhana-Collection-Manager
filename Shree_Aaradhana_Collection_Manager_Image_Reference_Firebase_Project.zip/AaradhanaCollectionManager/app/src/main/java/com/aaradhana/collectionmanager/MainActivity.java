package com.aaradhana.collectionmanager;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.Window;
import org.json.JSONObject;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.SetOptions;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends Activity {
    private WebView webView;
    private FirebaseFirestore firestore;
    private FirebaseAuth auth;
    private volatile String cloudStatus = "initializing";

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        FirebaseApp.initializeApp(this);
        firestore = FirebaseFirestore.getInstance();
        auth = FirebaseAuth.getInstance();

        webView = new WebView(this);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        webView.addJavascriptInterface(new CloudBridge(), "AaradhanaCloud");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");

        // Anonymous auth is a single-device bootstrap only. Multi-device access should
        // switch to named accounts/roles before real customer data is entered.
        auth.signInAnonymously().addOnCompleteListener(task -> {
            if (task.isSuccessful()) cloudStatus = "authenticated";
            else cloudStatus = "auth_error";
            notifyWebStatus();
        });
    }

    private void notifyWebStatus() {
        if (webView != null) webView.post(() ->
            webView.evaluateJavascript("window.onAaradhanaCloudStatus && window.onAaradhanaCloudStatus('" + cloudStatus + "')", null));
    }

    private class CloudBridge {
        @JavascriptInterface public String status() { return cloudStatus; }

        @JavascriptInterface public void saveSnapshot(String json) {
            if (auth.getCurrentUser() == null) {
                cloudStatus = "not_authenticated";
                notifyWebStatus();
                return;
            }
            try {
                JSONObject obj = new JSONObject(json);
                Map<String, Object> payload = new HashMap<>();
                payload.put("snapshotJson", obj.toString());
                payload.put("updatedAtMillis", System.currentTimeMillis());
                payload.put("schemaVersion", 1);
                String uid = auth.getCurrentUser().getUid();
                firestore.collection("users").document(uid)
                    .collection("appData").document("snapshot")
                    .set(payload, SetOptions.merge())
                    .addOnSuccessListener(v -> { cloudStatus = "synced"; notifyWebStatus(); })
                    .addOnFailureListener(e -> { cloudStatus = "sync_error"; notifyWebStatus(); });
            } catch (Exception e) {
                cloudStatus = "invalid_data";
                notifyWebStatus();
            }
        }

        @JavascriptInterface public void loadSnapshot() {
            if (auth.getCurrentUser() == null) {
                cloudStatus = "not_authenticated";
                notifyWebStatus();
                return;
            }
            String uid = auth.getCurrentUser().getUid();
            firestore.collection("users").document(uid)
                .collection("appData").document("snapshot").get()
                .addOnSuccessListener(doc -> {
                    if (doc.exists()) {
                        String json = doc.getString("snapshotJson");
                        if (json != null && webView != null) {
                            String escaped = JSONObject.quote(json);
                            webView.post(() -> webView.evaluateJavascript(
                                "window.onAaradhanaCloudSnapshot && window.onAaradhanaCloudSnapshot(" + escaped + ")", null));
                        }
                        cloudStatus = "loaded";
                    } else cloudStatus = "empty";
                    notifyWebStatus();
                })
                .addOnFailureListener(e -> { cloudStatus = "load_error"; notifyWebStatus(); });
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
