# Shree Aaradhana Collection Manager

Mobile-first Android WebView project. Existing Android launcher icon, splash image, Java activity files, Gradle configuration, and local-storage database key are preserved from the supplied project.

## Included modules
- Customer Master, Plan Master, Savings Collection, Monthly Schedule, Pending Collection, Ledger, Reports, Backup/Restore.
- Dashboard cards for Outstanding Collection and Outstanding EMIs.
- Gift Slab by exact monthly savings amount; Gift eligibility after six distinct paid savings months; Gift issue register/history.
- Loan Tracker with account-age and minimum-savings-month eligibility checks, self approval, pre-decided monthly EMI, repayment records, and reducing-balance outstanding estimate.
- Commission settings kept configurable because layer rates and the basis for the first-payment 100% rule are not confirmed.
- Branch and Advisor/Staff fields per customer with dashboard rollups.
- Language selector with translated navigation and key dashboard labels for Gujarati, Hindi, and English.
- JSON backup/restore includes new data collections and migration defaults.

## Important limitations
- Data remains local to the app's WebView storage on that device. This is not a cloud-synced or multi-device database.
- Loan interest rate, repayment rules, savings eligibility threshold, and commission rates must be confirmed against the society's official rules before financial use.
- Gift eligibility counts distinct months with a positive savings payment; it does not require consecutive months unless the society confirms that rule.
- The language selector currently translates navigation and key dashboard labels; complete translation of every form/table/report remains future work.
- This source ZIP has not been built into a verified APK in this environment. Build and device testing are still required.

## Updated multilingual UI and form-based workflows (October 2026)
- Language selector supports Gujarati, Hindi, and English; translation dictionaries cover navigation, dashboard KPIs, Gift, Loan, Commission, Reports, and common form labels. Some legacy/long-form labels and system alerts may still appear in English and should be checked in device QA.
- Gift slab setup, gift issuance, loan creation, EMI collection, and commission-rule editing use a structured modal form instead of browser prompt dialogs.
- Gift eligibility is based on six distinct paid savings months and an exact monthly-savings slab; gift issue history prevents duplicate issuance for the same member.
- Loan eligibility checks a one-year account age and configured minimum distinct savings months. EMI is pre-decided and recorded as a fixed installment; partial EMI allocation is intentionally not supported until society rules define it.
- Branch and staff aggregation was tested using synthetic test records only; no real branch/staff records were provided with the project.
- JavaScript syntax and focused logic checks passed with `node --check` and `qa_test.js`. An Android APK build/device test was not run in this environment.
